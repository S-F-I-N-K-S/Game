﻿namespace Race2;

public enum GameState
{
    MainMenu,
    Level,
    SelectCar,
    Educ,
    Playing
}

public enum Level
{
    SSW,
    Monza,
    Monaco
}